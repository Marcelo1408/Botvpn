class OpenVPNManager {
  constructor(ssh) {
    this.ssh = ssh;
  }

  async isActive() {
    const result = await this.ssh.execCommand('systemctl is-active openvpn');
    return result.stdout.trim() === 'active';
  }

  async getActiveUsers() {
    const result = await this.ssh.execCommand(`
      sudo cat /etc/openvpn/server/openvpn-status.log | 
      grep CLIENT_LIST | 
      awk '{print $2}'
    `);
    return result.stdout;
  }
}

module.exports = OpenVPNManager;