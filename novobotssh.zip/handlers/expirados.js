const fs = require('fs');
const path = require('path');

module.exports = (bot, msg, menuPrincipal) => {
    const chatId = msg.chat.id;
    const usuariosPath = path.join(__dirname, '../data/usuarios.json');

    try {
        // Verifica se o arquivo existe
        if (!fs.existsSync(usuariosPath)) {
            return bot.sendMessage(chatId, '❌ Nenhum usuário cadastrado ainda.', menuPrincipal);
        }

        // Carrega os usuários
        const usuarios = JSON.parse(fs.readFileSync(usuariosPath));
        const agora = new Date();

        // Filtra usuários expirados
        const expirados = usuarios.filter(usuario => {
            return new Date(usuario.expira_em) < agora;
        });

        // Ordena por data de expiração (mais antigos primeiro)
        expirados.sort((a, b) => new Date(a.expira_em) - new Date(b.expira_em));

        if (expirados.length === 0) {
            return bot.sendMessage(chatId, '✅ Nenhum usuário expirado encontrado.', menuPrincipal);
        }

        // Formata a mensagem
        let mensagem = '🔴 *Usuários Expirados:*\n\n';
        expirados.forEach((usuario, index) => {
            const dataExpiracao = new Date(usuario.expira_em).toLocaleDateString('pt-BR');
            const diasAtraso = Math.floor((agora - new Date(usuario.expira_em)) / (1000 * 60 * 60 * 24));
            
            mensagem += `▫️ *${usuario.nome}*\n` +
                       `📅 Expirou em: ${dataExpiracao}\n` +
                       `⏳ Atraso: ${diasAtraso} dias\n` +
                       `🔑 Senha: ||${usuario.senha}||\n` +
                       (index < expirados.length - 1 ? '\n' : '');
        });

        // Envia a mensagem
        bot.sendMessage(
            chatId,
            mensagem,
            {
                parse_mode: 'Markdown',
                ...menuPrincipal,
                disable_web_page_preview: true
            }
        );

    } catch (error) {
        bot.sendMessage(
            chatId,
            `❌ Erro ao listar usuários expirados:\n${error.message}`,
            menuPrincipal
        );
    }
};