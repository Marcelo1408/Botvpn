const fs = require('fs');
const path = require('path');
const conexaoSSH = require('../utils/conexaoSSH');

const estadosAlteracaoSenha = {};

module.exports = (bot, msg, menuPrincipal) => {
  const chatId = msg.chat.id;
  
  // Inicia o fluxo de alteração
  estadosAlteracaoSenha[chatId] = { etapa: 'nome' };
  bot.sendMessage(chatId, '🔢 Informe o nome do usuário para alterar a senha:');

  const handleResponse = async (resposta) => {
    if (!estadosAlteracaoSenha[chatId] || resposta.chat.id !== chatId) return;
    
    const currentState = estadosAlteracaoSenha[chatId];
    
    if (currentState.etapa === 'nome') {
      const username = resposta.text.trim();
      
      // Verificação básica do nome
      if (username.length === 0) {
        bot.sendMessage(chatId, '❌ Nome inválido!', menuPrincipal);
        delete estadosAlteracaoSenha[chatId];
        return;
      }

      estadosAlteracaoSenha[chatId] = {
        username: username,
        etapa: 'senha'
      };
      
      bot.sendMessage(
        chatId,
        '🔢 Informe a NOVA senha (4 dígitos):',
        menuPrincipal
      );
      
      bot.once('message', handleResponse);
      
    } else if (currentState.etapa === 'senha') {
      const novaSenha = resposta.text;
      const username = currentState.username;
      
      // Validação simples de 4 dígitos
      if (!/^\d{4}$/.test(novaSenha)) {
        bot.sendMessage(chatId, '❌ A senha deve conter exatamente 4 dígitos numéricos.', menuPrincipal);
        delete estadosAlteracaoSenha[chatId];
        return;
      }

      try {
        // Atualização direta sem confirmação
        const comando = `echo "${username}:${novaSenha}" | sudo chpasswd`;
        const ssh = await conexaoSSH();
        await ssh.execCommand(comando);
        ssh.dispose();

        // Atualiza o arquivo local
        const usuariosPath = path.join(__dirname, '../data/usuarios.json');
        if (fs.existsSync(usuariosPath)) {
          const usuarios = JSON.parse(fs.readFileSync(usuariosPath));
          const usuarioIndex = usuarios.findIndex(u => u.username === username);
          
          if (usuarioIndex !== -1) {
            usuarios[usuarioIndex].senha = novaSenha;
            usuarios[usuarioIndex].ultima_alteracao = new Date().toISOString();
            fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));
          }
        }

        // Confirmação simples
        bot.sendMessage(
          chatId,
          `✅ Senha de ${username} alterada para \`${novaSenha}\``,
          { parse_mode: 'Markdown', ...menuPrincipal }
        );

      } catch (error) {
        bot.sendMessage(
          chatId,
          `❌ Erro ao alterar senha: ${error.message}`,
          menuPrincipal
        );
      } finally {
        delete estadosAlteracaoSenha[chatId];
      }
    }
  };

  bot.once('message', handleResponse);
};