const fs = require('fs');
const path = require('path');
const conexaoSSH = require('../utils/conexaoSSH');

const estadosAlteracao = {};

module.exports = (bot, msg, menuPrincipal) => {
  const chatId = msg.chat.id;
  
  // Inicia o fluxo de alteração
  estadosAlteracao[chatId] = { etapa: 'nome' };
  bot.sendMessage(chatId, '🔍 Informe o nome do usuário que deseja alterar:');

  const handleResponse = async (resposta) => {
    if (!estadosAlteracao[chatId] || resposta.chat.id !== chatId) return;
    
    const currentState = estadosAlteracao[chatId];
    
    if (currentState.etapa === 'nome') {
      const username = resposta.text.trim();
      
      // Validação reforçada do nome de usuário
      if (!/^[a-z_][a-z0-9_-]{0,31}$/i.test(username)) {
        bot.sendMessage(chatId, '❌ Nome inválido! Use 1-32 caracteres (letras, números, hífens ou _)', menuPrincipal);
        delete estadosAlteracao[chatId];
        return;
      }

      // Verificação de existência do usuário
      try {
        const comandoVerificacao = `id ${username} >/dev/null 2>&1 && echo "EXISTS" || echo "NOT_FOUND"`;
        const ssh = await conexaoSSH();
        const { stdout } = await ssh.execCommand(comandoVerificacao);
        ssh.dispose();
        
        if (stdout.includes('NOT_FOUND')) {
          bot.sendMessage(chatId, `❌ Usuário "${username}" não encontrado no servidor.`, menuPrincipal);
          delete estadosAlteracao[chatId];
          return;
        }

        // Verifica se existe no arquivo local
        const usuariosPath = path.join(__dirname, '../data/usuarios.json');
        if (fs.existsSync(usuariosPath)) {
          const usuarios = JSON.parse(fs.readFileSync(usuariosPath));
          const usuarioExistente = usuarios.find(u => u.username === username);
          
          if (!usuarioExistente) {
            bot.sendMessage(chatId, `⚠️ Usuário encontrado no servidor mas não no registro local. Continuando...`);
          }
        }

        estadosAlteracao[chatId] = {
          username: username,
          etapa: 'dias'
        };
        bot.sendMessage(chatId, '📅 Informe os NOVOS dias de acesso (número inteiro positivo):\n\nDigite 0 para remover a expiração', menuPrincipal);
        bot.once('message', handleResponse);
        
      } catch (error) {
        console.error('Erro na verificação:', error);
        bot.sendMessage(chatId, '❌ Erro ao verificar usuário. Tente novamente.', menuPrincipal);
        delete estadosAlteracao[chatId];
      }
      
    } else if (currentState.etapa === 'dias') {
      const diasInput = resposta.text.trim();
      const username = currentState.username;
      
      // Validação melhorada dos dias
      if (!/^-?\d+$/.test(diasInput)) {
        bot.sendMessage(chatId, '❌ Valor inválido! Digite apenas números inteiros.', menuPrincipal);
        delete estadosAlteracao[chatId];
        return;
      }

      const dias = parseInt(diasInput);
      if (dias < 0) {
        bot.sendMessage(chatId, '❌ O número de dias não pode ser negativo.', menuPrincipal);
        delete estadosAlteracao[chatId];
        return;
      }

      try {
        // Prepara data de expiração
        const dataExpiracao = dias === 0 ? null : new Date(Date.now() + dias * 86400000);
        const dataFormatadaSSH = dias === 0 ? '' : dataExpiracao.toISOString().split('T')[0];
        
        // Comando SSH para atualizar
        const comando = dias === 0 
          ? `sudo chage -E -1 ${username}` // Remove expiração
          : `sudo chage -E ${dataFormatadaSSH} ${username}`;
        
        const ssh = await conexaoSSH();
        const { stderr } = await ssh.execCommand(comando);
        ssh.dispose();

        if (stderr) throw new Error(stderr);

        // Atualização do arquivo local
        const usuariosPath = path.join(__dirname, '../data/usuarios.json');
        if (!fs.existsSync(usuariosPath)) {
          throw new Error('Arquivo de usuários não encontrado');
        }

        const usuarios = JSON.parse(fs.readFileSync(usuariosPath));
        const usuarioIndex = usuarios.findIndex(u => u.username === username); // Corrigido para username
        
        if (usuarioIndex === -1) {
          // Se não existir localmente, adiciona um novo registro
          usuarios.push({
            username: username,
            data_criacao: new Date().toISOString(),
            expira_em: dataExpiracao?.toISOString() || null,
            ultima_atualizacao: new Date().toISOString()
          });
        } else {
          // Atualiza registro existente
          usuarios[usuarioIndex] = {
            ...usuarios[usuarioIndex],
            expira_em: dataExpiracao?.toISOString() || null,
            ultima_atualizacao: new Date().toISOString()
          };
        }

        fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));

        // Verificação pós-escrita
        const dadosAtualizados = JSON.parse(fs.readFileSync(usuariosPath));
        const usuarioAtualizado = dadosAtualizados.find(u => u.username === username);
        
        if (!usuarioAtualizado) {
          throw new Error('Falha ao confirmar a atualização no arquivo local');
        }

        // Formatação para exibição
        const formatarData = (iso) => iso ? new Date(iso).toLocaleDateString('pt-BR') : 'Sem expiração';
        
        const mensagemSucesso = dias === 0
          ? `♾️ *Expiração removida!* O usuário \`${username}\` não terá data de expiração.`
          : `✅ *Validade atualizada!*\n\n` +
            `👤: \`${username}\`\n` +
            `📅 Nova validade: ${formatarData(dataExpiracao?.toISOString())}\n` +
            `⏳ Dias adicionados: ${dias}`;

        bot.sendMessage(chatId, mensagemSucesso, { parse_mode: 'Markdown', ...menuPrincipal });

      } catch (error) {
        console.error('Erro na alteração:', error);
        const mensagemErro = error.message.includes('Arquivo')
          ? '❌ Problema no banco de dados local'
          : `❌ Falha na alteração: ${error.message}`;
        
        bot.sendMessage(chatId, mensagemErro, menuPrincipal);
      } finally {
        delete estadosAlteracao[chatId];
      }
    }
  };

  bot.once('message', handleResponse);
};