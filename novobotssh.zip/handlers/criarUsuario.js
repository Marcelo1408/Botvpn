const fs = require('fs');
const path = require('path');
const conexaoSSH = require('../utils/conexaoSSH');

// Objeto para controlar o estado da conversa por chat
const estados = {};

module.exports = (bot, msg, menuPrincipal) => {
  const chatId = msg.chat.id;
  
  // Inicia o fluxo de criação
  estados[chatId] = { etapa: 'nome' };
  bot.sendMessage(chatId, '✅ Informe o nome de usuário:');

  bot.once('message', (resposta) => {
    if (!estados[chatId] || resposta.chat.id !== chatId) return;
    estados[chatId].username = resposta.text;
    estados[chatId].etapa = 'senha';
    bot.sendMessage(chatId, '🔑 Informe a senha:');

    bot.once('message', (resposta) => {
      if (!estados[chatId] || resposta.chat.id !== chatId) return;
      estados[chatId].senha = resposta.text;
      estados[chatId].etapa = 'dias';
      bot.sendMessage(chatId, '📅 Quantos dias de acesso?');

      bot.once('message', (resposta) => {
        if (!estados[chatId] || resposta.chat.id !== chatId) return;
        estados[chatId].dias = resposta.text;
        estados[chatId].etapa = 'limite';
        bot.sendMessage(chatId, '🔢 Limite de conexões simultâneas:');

        bot.once('message', async (resposta) => {
          if (!estados[chatId] || resposta.chat.id !== chatId) return;
          const username = estados[chatId].username;
          const senha = estados[chatId].senha;
          const dias = parseInt(estados[chatId].dias, 10);
          const limite = parseInt(resposta.text, 10);

          if (isNaN(dias) || dias <= 0) {
            bot.sendMessage(chatId, '❌ Dias inválidos. Operação cancelada.', menuPrincipal);
            delete estados[chatId];
            return;
          }
          if (isNaN(limite) || limite <= 0) {
            bot.sendMessage(chatId, '❌ Limite inválido. Operação cancelada.', menuPrincipal);
            delete estados[chatId];
            return;
          }

          try {
            // Comando SSH otimizado
            const comando = `
sudo useradd -m -s /bin/bash ${username} && 
echo "${username}:${senha}" | sudo chpasswd && 
sudo chage -E $(date -d "+${dias} days" +%Y-%m-%d) ${username} && 
echo "${username} hard maxlogins ${limite}" | sudo tee -a /etc/security/limits.conf
            `;

            // Executa via SSH (usando .env)
            const ssh = await conexaoSSH();
            await ssh.execCommand(comando);
            ssh.dispose();

            // Calcula a data de expiração formatada
            const dataExpiracao = new Date(Date.now() + dias * 86400000);
            const dataFormatada = dataExpiracao.toLocaleDateString('pt-BR');

            // Atualiza o arquivo local (data/usuarios.json)
            const usuariosPath = path.join(__dirname, '../data/usuarios.json');
            const usuarios = fs.existsSync(usuariosPath) ? 
              JSON.parse(fs.readFileSync(usuariosPath)) : [];

            usuarios.push({
              username: username,
              senha: senha,
              data_criacao: new Date().toISOString(),
              expira_em: dataExpiracao.toISOString(),
              limite_conexoes: limite
            });

            fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));

            // Confirmação com data formatada
            bot.sendMessage(
              chatId,
              `🎉 *Usuário criado!*\n\n` +
              `👤: \`${username}\`\n` +
              `🔑: \`${senha}\`\n` +
              `📅 Validade: ${dataFormatada}\n` +
              `⏳ Dias: ${dias}\n` +
              `🔌 Limite: ${limite} conexões`,
              { parse_mode: 'Markdown', ...menuPrincipal }
            );

          } catch (error) {
            bot.sendMessage(
              chatId,
              `❌ Falha ao criar usuário:\n\n${error.message}`,
              menuPrincipal
            );
          } finally {
            delete estados[chatId]; // Limpa o estado
          }
        });
      });
    });
  });
};