const conexaoSSH = require('../utils/conexaoSSH');

module.exports = async (bot, msg, menuPrincipal) => {
  const chatId = msg.chat.id;

  try {
    const processingMsg = await bot.sendMessage(chatId, '🔄 Verificando usuários online...');
    const ssh = await conexaoSSH();

    // Comando otimizado para detectar usuários online com tempo de conexão
    const cmd = `
      awk -F: '$3>=1000{print $1}' /etc/passwd | grep -v nobody | while read user; do
        sshd=$(ps -o etime= -u "$user" | grep -v '00:00' | wc -l);
        [ "$sshd" -gt 0 ] && {
          time=$(ps -o etime= -u "$user" | head -n1 | awk '{print $1}');
          echo "$user $time";
        };
      done
    `;

    const onlineResult = await ssh.execCommand(cmd);
    ssh.dispose();

    // Processa usuários online
    const onlineUsers = onlineResult.stdout.split('\n')
      .filter(line => line.trim() !== '')
      .map(line => {
        const [username, time] = line.trim().split(/\s+/);
        return {
          username,
          time: formatTime(time)
        };
      });

    // Monta mensagem no formato solicitado
    let message = '👤 *Usuários Online*:\n\n';
    
    if (onlineUsers.length === 0) {
      message += 'Nenhum usuário conectado no momento.\n';
    } else {
      onlineUsers.forEach(user => {
        message += `🟢 *${user.username}* (${user.time})\n\n`;
      });
      message += `📊 Total: *${onlineUsers.length}* usuário(s) online`;
    }

    await bot.deleteMessage(chatId, processingMsg.message_id);
    await bot.sendMessage(chatId, message, {
      parse_mode: 'Markdown',
      reply_markup: menuPrincipal.reply_markup
    });

  } catch (error) {
    console.error('Erro ao verificar usuários online:', error);
    await bot.sendMessage(
      chatId,
      '❌ Erro ao verificar usuários online. Verifique os logs do servidor.',
      { reply_markup: menuPrincipal.reply_markup }
    );
  }
};

// Formata tempo de conexão (simplificado)
function formatTime(time) {
  if (!time) return 'ativo agora';
  
  // Remove segundos se for formato HH:MM:SS
  if (time.match(/^\d+:\d+:\d+$/)) {
    return time.split(':').slice(0, 2).join(':') + 'h';
  }
  
  // Formato com dias (DD-HH:MM:SS)
  if (time.includes('-')) {
    const [days, hms] = time.split('-');
    const hours = hms.split(':')[0];
    return `${days}d ${hours}h`;
  }
  
  return time;
}