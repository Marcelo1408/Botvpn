const fs = require('fs');
const path = require('path');

module.exports = function(bot, msg, menuPrincipal) {
  const chatId = msg.chat.id;
  const estado = {
    etapa: 'inicio',
    dados: {}
  };

  // Função para iniciar o processo
  const iniciarCadastro = () => {
    estado.etapa = 'solicitar_nome';
    bot.sendMessage(chatId, '🏷️ Digite um nome amigável para este servidor (ex: "Servidor Principal"):');
  };

  // Handler para processar as mensagens
  bot.on('message', async (responseMsg) => {
    if (responseMsg.chat.id !== chatId) return;

    try {
      switch (estado.etapa) {
        case 'solicitar_nome':
          estado.dados.nome = responseMsg.text.trim();
          if (!estado.dados.nome) {
            return bot.sendMessage(chatId, '❌ O nome não pode estar vazio!', menuPrincipal);
          }
          estado.etapa = 'solicitar_ip';
          bot.sendMessage(chatId, '🔹 Digite o IP do servidor:');
          break;

        case 'solicitar_ip':
          estado.dados.host = responseMsg.text.trim();
          if (!estado.dados.host) {
            return bot.sendMessage(chatId, '❌ O IP não pode estar vazio!', menuPrincipal);
          }
          estado.etapa = 'solicitar_usuario';
          bot.sendMessage(chatId, '👤 Digite o usuário SSH (ex: root):');
          break;

        case 'solicitar_usuario':
          estado.dados.user = responseMsg.text.trim();
          if (!estado.dados.user) {
            return bot.sendMessage(chatId, '❌ O usuário não pode estar vazio!', menuPrincipal);
          }
          estado.etapa = 'solicitar_senha';
          bot.sendMessage(chatId, '🔒 Digite a senha do servidor:');
          break;

        case 'solicitar_senha':
          const senha = responseMsg.text.trim();
          if (!senha) {
            return bot.sendMessage(chatId, '❌ A senha não pode estar vazia!', menuPrincipal);
          }
          if (senha.includes('\n') || senha.includes('\r')) {
            return bot.sendMessage(chatId, '❌ Senha não pode conter quebras de linha!', menuPrincipal);
          }
          estado.dados.password = senha;
          estado.etapa = 'solicitar_porta';
          bot.sendMessage(chatId, '🚪 Digite a porta SSH (padrão 22):');
          break;

        case 'solicitar_porta':
          estado.dados.port = responseMsg.text.trim() || '22';
          
          // Validação final
          if (!estado.dados.nome || !estado.dados.host || !estado.dados.user || !estado.dados.password) {
            return bot.sendMessage(chatId, '❌ Dados incompletos! Operação cancelada.', menuPrincipal);
          }

          await finalizarCadastro();
          break;

        default:
          break;
      }
    } catch (error) {
      console.error('Erro no cadastro:', error);
      bot.sendMessage(chatId, '❌ Ocorreu um erro. Por favor, comece novamente.', menuPrincipal);
      estado.etapa = 'inicio';
    }
  });

  // Função para finalizar o cadastro
  const finalizarCadastro = async () => {
    const { nome, host, user, password, port } = estado.dados;

    try {
      // 1. Atualizar .env (sem o nome, apenas dados de conexão)
      const envPath = path.join(__dirname, '..', '.env');
      let envContent = fs.existsSync(envPath) ? fs.readFileSync(envPath, 'utf8') : '';

      envContent = envContent
        .split('\n')
        .filter(line => !line.startsWith('SERVER_'))
        .join('\n');

      // Adiciona aspas simples na senha e escapa aspas existentes
      const senhaFormatada = `'${password.replace(/'/g, "\\'")}'`;
      
      envContent += `\nSERVER_HOST=${host}\nSERVER_USER=${user}\nSERVER_PASSWORD=${senhaFormatada}\nSERVER_PORT=${port}\n`;
      fs.writeFileSync(envPath, envContent.trim(), 'utf8');

      // 2. Atualizar servidores.json (com nome)
      const servidoresPath = path.join(__dirname, '..', 'data', 'servidores.json');
      let servidores = [];

      if (fs.existsSync(servidoresPath)) {
        try {
          servidores = JSON.parse(fs.readFileSync(servidoresPath, 'utf8'));
        } catch (err) {
          console.error('Erro ao ler servidores.json:', err);
        }
      }

      // Atualiza ou adiciona servidor
      const index = servidores.findIndex(s => s.host === host);
      if (index >= 0) {
        servidores[index] = { nome, host, user, password, port };
      } else {
        servidores.push({ nome, host, user, password, port });
      }

      fs.writeFileSync(servidoresPath, JSON.stringify(servidores, null, 2));

      // 3. Confirmar cadastro
      const resposta = `
✅ *Servidor cadastrado com sucesso!*

📛 *Nome:* ${nome}
📡 *Conexão:*
   - IP: \`${host}\`
   - Usuário: \`${user}\`
   - Porta: \`${port}\`

💾 Backup salvo em servidores.json
      `;

      await bot.sendMessage(
        chatId, 
        resposta, 
        { 
          parse_mode: 'Markdown',
          ...menuPrincipal
        }
      );

    } catch (error) {
      console.error('Erro ao salvar servidor:', error);
      await bot.sendMessage(
        chatId, 
        '❌ Erro ao salvar as informações do servidor.', 
        menuPrincipal
      );
    } finally {
      // Limpa o estado
      estado.etapa = 'inicio';
      estado.dados = {};
      bot.removeListener('message');
    }
  };

  // Inicia o processo
  iniciarCadastro();
};