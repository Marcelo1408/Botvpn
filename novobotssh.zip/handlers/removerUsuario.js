const fs = require('fs');
const path = require('path');
const conexaoSSH = require('../utils/conexaoSSH');

const estadosRemocao = {};

module.exports = (bot, msg, menuPrincipal) => {
  const chatId = msg.chat.id;
  const usuariosPath = path.join(__dirname, '../data/usuarios.json');
  
  estadosRemocao[chatId] = { etapa: 'nome' };
  bot.sendMessage(chatId, '🗑️ Informe o nome do usuário que deseja REMOVER:');

  bot.once('message', async (resposta) => {
    if (!estadosRemocao[chatId] || resposta.chat.id !== chatId) return;
    const username = resposta.text;
    
    try {
      // 1. Remove no servidor via SSH
      const comando = `sudo userdel -r ${username}`;
      const ssh = await conexaoSSH();
      const resultado = await ssh.execCommand(comando);
      
      if (resultado.stderr && resultado.stderr.includes('does not exist')) {
        throw new Error('USER_NOT_FOUND');
      }
      
      ssh.dispose();

      // 2. Remove do arquivo local
      if (!fs.existsSync(usuariosPath)) {
        throw new Error('FILE_NOT_FOUND');
      }

      const usuarios = JSON.parse(fs.readFileSync(usuariosPath));
      const usuarioIndex = usuarios.findIndex(u => u.nome === username);
      
      if (usuarioIndex === -1) {
        bot.sendMessage(chatId, '⚠️ Usuário removido do servidor, mas não encontrado no registro local.', menuPrincipal);
        return;
      }

      const usuarioRemovido = usuarios.splice(usuarioIndex, 1)[0];
      fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));

      // 3. Feedback
      const dataFormatada = new Date().toLocaleString('pt-BR');
      bot.sendMessage(
        chatId,
        `❌ *Usuário removido com sucesso!*\n\n` +
        `👤 Nome: \`${username}\`\n` +
        `📅 Data de criação: ${new Date(usuarioRemovido.data_criacao).toLocaleDateString('pt-BR')}\n` +
        `⏱️ Remoção: ${dataFormatada}`,
        { parse_mode: 'Markdown', ...menuPrincipal }
      );

    } catch (error) {
      if (error.message === 'USER_NOT_FOUND') {
        // Usuário não existe no servidor
        bot.sendMessage(
          chatId,
          `⚠️ O usuário "${username}" não existe no servidor. Deseja remover do registro local? (sim/não)`,
          { reply_markup: { force_reply: true } }
        );

        bot.once('message', (resposta) => {
          if (resposta.text.toLowerCase() === 'sim') {
            try {
              if (!fs.existsSync(usuariosPath)) {
                bot.sendMessage(chatId, '❌ Arquivo de usuários não encontrado.', menuPrincipal);
                return;
              }
              
              const usuarios = JSON.parse(fs.readFileSync(usuariosPath));
              const updatedUsers = usuarios.filter(u => u.nome !== username);
              
              if (usuarios.length === updatedUsers.length) {
                bot.sendMessage(chatId, `ℹ️ O usuário "${username}" não foi encontrado no registro local.`, menuPrincipal);
                return;
              }
              
              fs.writeFileSync(usuariosPath, JSON.stringify(updatedUsers, null, 2));
              bot.sendMessage(chatId, `✅ "${username}" removido do registro local.`, menuPrincipal);
            } catch (fileError) {
              bot.sendMessage(chatId, `❌ Erro ao acessar registro local: ${fileError.message}`, menuPrincipal);
            }
          } else {
            bot.sendMessage(chatId, 'Operação cancelada.', menuPrincipal);
          }
        });

      } else if (error.message === 'FILE_NOT_FOUND') {
        bot.sendMessage(chatId, '❌ Arquivo de usuários não encontrado.', menuPrincipal);
      } else {
        bot.sendMessage(
          chatId,
          `❌ Falha ao remover usuário:\n\n${error.message}`,
          menuPrincipal
        );
      }
    } finally {
      delete estadosRemocao[chatId];
    }
  });
};