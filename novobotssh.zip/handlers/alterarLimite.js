const fs = require('fs');
const path = require('path');
const conexaoSSH = require('../utils/conexaoSSH');

// Objeto para controlar o estado da conversa
const estadosAlteracaoLimite = {};

module.exports = (bot, msg, menuPrincipal) => {
  const chatId = msg.chat.id;
  
  // Inicia o fluxo de alteração
  estadosAlteracaoLimite[chatId] = { etapa: 'nome' };
  bot.sendMessage(chatId, '🔍 Informe o nome do usuário que deseja alterar o limite de conexões:');

  // Função para lidar com as respostas
  const handleResponse = async (resposta) => {
    if (!estadosAlteracaoLimite[chatId] || resposta.chat.id !== chatId) return;
    
    const currentState = estadosAlteracaoLimite[chatId];
    
    if (currentState.etapa === 'nome') {
      const username = resposta.text.trim();
      
      // Validação básica do nome de usuário
      if (username.length === 0 || username.length > 32) {
        bot.sendMessage(chatId, '❌ Nome de usuário inválido! Deve ter entre 1 e 32 caracteres.', menuPrincipal);
        delete estadosAlteracaoLimite[chatId];
        return;
      }

      // Verifica se o usuário existe
      try {
        const comandoVerificacao = `id ${username} >/dev/null 2>&1 && echo "EXISTS" || echo "NOT_FOUND"`;
        const ssh = await conexaoSSH();
        const { stdout } = await ssh.execCommand(comandoVerificacao);
        ssh.dispose();
        
        if (stdout.includes('NOT_FOUND')) {
          bot.sendMessage(chatId, `❌ Usuário "${username}" não encontrado no servidor.`, menuPrincipal);
          delete estadosAlteracaoLimite[chatId];
          return;
        }

        // Se usuário existe, avança para a próxima etapa
        estadosAlteracaoLimite[chatId] = {
          username: username,
          etapa: 'limite'
        };
        
        bot.sendMessage(
          chatId,
          '🔢 Informe o NOVO limite de conexões simultâneas:\n\n' +
          '• Digite um número inteiro positivo\n' +
          '• 0 para ilimitado (não recomendado)\n' +
          '• Recomendado: 1-3 conexões',
          menuPrincipal
        );
        
        bot.once('message', handleResponse);
        
      } catch (error) {
        bot.sendMessage(chatId, `❌ Erro ao verificar usuário: ${error.message}`, menuPrincipal);
        delete estadosAlteracaoLimite[chatId];
      }
      
    } else if (currentState.etapa === 'limite') {
      const limiteInput = resposta.text.trim();
      const username = currentState.username;
      
      // Validação do limite
      if (!/^\d+$/.test(limiteInput)) {
        bot.sendMessage(chatId, '❌ Valor inválido! Digite apenas números inteiros.', menuPrincipal);
        delete estadosAlteracaoLimite[chatId];
        return;
      }

      const limite = parseInt(limiteInput);
      if (limite < 0) {
        bot.sendMessage(chatId, '❌ O limite não pode ser negativo.', menuPrincipal);
        delete estadosAlteracaoLimite[chatId];
        return;
      }

      try {
        // Comando para atualizar o limite no servidor
        let comando = `sudo sed -i '/${username} hard maxlogins/d' /etc/security/limits.conf`;
        
        if (limite > 0) {
          comando += ` && echo "${username} hard maxlogins ${limite}" | sudo tee -a /etc/security/limits.conf`;
        }
        
        const ssh = await conexaoSSH();
        await ssh.execCommand(comando);
        ssh.dispose();

        // Atualiza no arquivo local
        const usuariosPath = path.join(__dirname, '../data/usuarios.json');
        if (fs.existsSync(usuariosPath)) {
          const usuarios = JSON.parse(fs.readFileSync(usuariosPath));
          const usuarioIndex = usuarios.findIndex(u => u.username === username);
          
          if (usuarioIndex !== -1) {
            usuarios[usuarioIndex].limite_conexoes = limite;
            usuarios[usuarioIndex].ultima_alteracao = new Date().toISOString();
            fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));
          }
        }

        // Mensagem de confirmação
        const msgLimite = limite === 0 ? 'ilimitadas' : `${limite} conexão(s)`;
        
        bot.sendMessage(
          chatId,
          `✅ *Limite de conexões atualizado!*\n\n` +
          `👤 Usuário: \`${username}\`\n` +
          `🔌 Novo limite: ${msgLimite}\n` +
          `📅 Alterado em: ${new Date().toLocaleString('pt-BR')}`,
          { parse_mode: 'Markdown', ...menuPrincipal }
        );

      } catch (error) {
        bot.sendMessage(
          chatId,
          `❌ Falha ao alterar limite:\n\n${error.message}`,
          menuPrincipal
        );
      } finally {
        delete estadosAlteracaoLimite[chatId];
      }
    }
  };

  bot.once('message', handleResponse);
};