const fs = require('fs');
const path = require('path');

module.exports = (bot, msg, menuPrincipal) => {
  const chatId = msg.chat.id;
  const filePath = path.join(__dirname, '../data/servidores.json');

  // Verifica se existe o arquivo e se não está vazio
  if (!fs.existsSync(filePath) || fs.readFileSync(filePath, 'utf8').trim() === '[]') {
    return bot.sendMessage(chatId, '⚠️ Nenhum servidor cadastrado.', menuPrincipal);
  }

  bot.sendMessage(chatId, '🗑️ *Informe o nome do servidor que deseja excluir:*', { parse_mode: 'Markdown' });

  bot.once('message', (nomeMsg) => {
    const nome = nomeMsg.text.trim();

    try {
      const data = fs.readFileSync(filePath, 'utf8');
      let servidores = JSON.parse(data);

      const index = servidores.findIndex(srv => srv.nome.toLowerCase() === nome.toLowerCase());

      if (index === -1) {
        return bot.sendMessage(chatId, `⚠️ Servidor *${nome}* não encontrado.`, { parse_mode: 'Markdown', ...menuPrincipal });
      }

      // Confirmação antes de excluir
      bot.sendMessage(chatId, `❓ Tem certeza que deseja excluir o servidor *${nome}*? (sim/não)`, { parse_mode: 'Markdown' });

      bot.once('message', (confirmMsg) => {
        const confirmacao = confirmMsg.text.trim().toLowerCase();

        if (confirmacao !== 'sim') {
          return bot.sendMessage(chatId, '❌ Operação cancelada.', menuPrincipal);
        }

        servidores.splice(index, 1);
        fs.writeFileSync(filePath, JSON.stringify(servidores, null, 2));

        bot.sendMessage(chatId, `✅ Servidor *${nome}* excluído com sucesso!`, { parse_mode: 'Markdown', ...menuPrincipal });
      });

    } catch (err) {
      console.error('Erro ao excluir servidor:', err);
      bot.sendMessage(chatId, '❌ Erro ao excluir servidor.', menuPrincipal);
    }
  });
};
