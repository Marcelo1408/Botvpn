const fs = require('fs');
const path = require('path');
const conexaoSSH = require('../utils/conexaoSSH');

function gerarUsuarioTeste() {
  const numero = Math.floor(100 + Math.random() * 900);
  return `teste${numero}`;
}

module.exports = async (bot, msg, menuPrincipal) => {
  const chatId = msg.chat.id;

  try {
    // Solicita horas de duração
    await bot.sendMessage(chatId, '⏰ Quantas horas de teste?');

    const horasMsg = await new Promise((resolve) => {
      bot.once('message', resolve);
    });

    const horas = parseInt(horasMsg.text);
    if (isNaN(horas)) {
      return bot.sendMessage(chatId, '⚠️ Digite um número válido de horas.');
    }

    // Gera credenciais
    const username = gerarUsuarioTeste();
    const senha = username; // Senha igual ao usuário para testes

    // Calcula data de expiração
    const expiracao = new Date(Date.now() + horas * 3600000);
    const dataExpiracao = expiracao.toISOString().split('T')[0]; // Formato YYYY-MM-DD

    // Comando SSH para criar usuário teste
    const comando = `
sudo useradd -m -s /bin/bash ${username} &&
echo "${username}:${senha}" | sudo chpasswd &&
sudo chage -E ${dataExpiracao} ${username} &&
echo "${username} hard maxlogins 1" | sudo tee -a /etc/security/limits.conf
    `;

    // Executa no servidor (usando credenciais do .env)
    const ssh = await conexaoSSH();
    await ssh.execCommand(comando);
    ssh.dispose();

    // Registra localmente
    const usuariosPath = path.join(__dirname, '../data/usuarios.json');
    const usuarios = fs.existsSync(usuariosPath) ? 
      JSON.parse(fs.readFileSync(usuariosPath)) : [];

    usuarios.push({
      nome: username,
      senha: senha,
      tipo: 'teste',
      criado_em: new Date().toISOString(),
      expira_em: expiracao.toISOString(),
      limite: 1
    });

    fs.writeFileSync(usuariosPath, JSON.stringify(usuarios, null, 2));

    // Resposta formatada
    await bot.sendMessage(
      chatId,
      `🎯 *CONTA TESTE CRIADA!*\n\n` +
      `👤 Nome: \`${username}\`\n` +
      `🔑 Senha: \`${senha}\`\n` +
      `⏳ Expira em: ${horas}h (${dataExpiracao})\n` +
      `🔌 Conexões: 1 simultânea`,
      { parse_mode: 'Markdown', ...menuPrincipal }
    );

  } catch (error) {
    console.error('Erro ao criar teste:', error);
    bot.sendMessage(
      chatId,
      `❌ Falha ao criar teste:\n${error.message}`,
      menuPrincipal
    );
  }
};