require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');
const conexaoSSH = require('./utils/conexaoSSH');

// =============================================
// 1. VALIDAÇÃO E CONFIGURAÇÃO INICIAL
// =============================================

// Variáveis obrigatórias (bot + servidor)
const requiredEnvVars = ['BOT_TOKEN', 'ADM_ID', 'SERVER_HOST', 'SERVER_USER', 'SERVER_PASSWORD'];
const missingVars = requiredEnvVars.filter(v => !process.env[v]);

if (missingVars.length > 0) {
  console.error(`❌ Variáveis de ambiente faltando: ${missingVars.join(', ')}`);
  process.exit(1);
}

// Verifica se o arquivo de usuários existe (data/usuarios.json)
const usuariosPath = path.join(__dirname, 'data', 'usuarios.json');
if (!fs.existsSync(usuariosPath)) {
  fs.writeFileSync(usuariosPath, '[]', 'utf8');
}

// =============================================
// 2. CONTROLE DE INSTÂNCIA ÚNICA (MANTIDO)
// =============================================

const LOCK_FILE = path.join(__dirname, 'bot.lock');

const isProcessActive = (pid) => {
  try {
    if (process.platform === 'win32') {
      const { execSync } = require('child_process');
      const output = execSync(`tasklist /fi "PID eq ${pid}"`).toString();
      return output.includes(pid.toString());
    }
    return process.kill(pid, 0);
  } catch {
    return false;
  }
};

if (fs.existsSync(LOCK_FILE)) {
  try {
    const runningPid = parseInt(fs.readFileSync(LOCK_FILE, 'utf8'));
    if (isProcessActive(runningPid)) {
      console.error(`❌ Bot já em execução (PID: ${runningPid}). Encerre-o primeiro.`);
      process.exit(1);
    } else {
      console.log('⚠️ Removendo lock file de processo inativo...');
      fs.unlinkSync(LOCK_FILE);
    }
  } catch (err) {
    console.error('⚠️ Erro ao verificar lock file:', err.message);
    fs.unlinkSync(LOCK_FILE);
  }
}

fs.writeFileSync(LOCK_FILE, String(process.pid));

// =============================================
// 3. INICIALIZAÇÃO DO BOT (MANTIDO)
// =============================================

let bot;
try {
  bot = new TelegramBot(process.env.BOT_TOKEN, {
    polling: {
      interval: 2000,
      params: {
        timeout: 10,
        allowed_updates: ['message', 'callback_query']
      }
    },
    request: {
      timeout: 10000
    }
  });
} catch (err) {
  console.error('❌ Falha ao iniciar o bot:', err.message);
  cleanup();
  process.exit(1);
}

bot.on('polling_error', (error) => {
  console.error(`Erro no polling: ${error.message}`);
});

// =============================================
// 4. MENU E HANDLERS (MANTIDO)
// =============================================

const nomeBot = "📡 VPS Manager Bot";

const menuPrincipal = {
  reply_markup: {
    keyboard: [
      ['👤 Criar Usuário', '📝 Criar Teste'],
      ['🔑 Alterar Senha', '🔌 Alterar Limite'],
      ['📊 Add Servidor', '📅 Alterar Data'],
      ['🟢 Onlines', '📃 Informações'],
      ['⏳ Expirados', '📦 Backup', '❌ Remover', ],
      ['📋 Listar Servidores', '🗑️ Excluir Servidor'],
      
    ],
    resize_keyboard: true,
    one_time_keyboard: false
  }
};

const loadHandler = (handlerPath) => {
  try {
    const handler = require(handlerPath);
    return typeof handler === 'function' ? handler : () => {};
  } catch (err) {
    console.error(`❌ Erro ao carregar handler ${handlerPath}:`, err.message);
    return () => console.error('Handler não disponível');
  }
};

const handlers = {
  '👤 Criar Usuário': loadHandler('./handlers/criarUsuario'),
  '📝 Criar Teste': loadHandler('./handlers/criarTeste'),
  '❌ Remover': loadHandler('./handlers/removerUsuario'),
  '🔑 Alterar Senha': loadHandler('./handlers/alterarSenha'),
  '📊 Add Servidor': loadHandler('./handlers/addServidor'),
  '📋 Listar Servidores': loadHandler('./handlers/listarServidores'),
  '🗑️ Excluir Servidor': loadHandler('./handlers/excluirServidor'),
  '📅 Alterar Data': loadHandler('./handlers/alterarData'),
  '🟢 Onlines': loadHandler('./handlers/onlines'),
  '📃 Informações': require('./handlers/informacoes')(conexaoSSH),
  '⏳ Expirados': loadHandler('./handlers/expirados'),
  '📦 Backup': loadHandler('./handlers/backup'),
  '🔌Alterar Limite': loadHandler('./handlers/AlterarLimite')
};

// =============================================
// 5. COMANDOS E MENSAGENS (MANTIDO)
// =============================================

const isAdmin = (msg) => msg.from.id.toString() === process.env.ADM_ID;

const authMiddleware = (handler) => (msg, match) => {
  if (!isAdmin(msg)) {
    return bot.sendMessage(msg.chat.id, '❌ Acesso restrito ao administrador!');
  }
  return handler(msg, match);
};

bot.onText(/\/start/, authMiddleware((msg) => {
  bot.sendMessage(msg.chat.id, `Bem-vindo ao ${nomeBot}`, menuPrincipal);
}));

bot.onText(/\/conexoes(?: (.+))?/, authMiddleware((msg, match) => {
  require('./comandos/conexoes')(bot, msg, menuPrincipal);
}));

bot.on('message', (msg) => {
  if (!isAdmin(msg)) return;

  const handler = handlers[msg.text];
  if (handler) {
    handler(bot, msg, menuPrincipal);
  }
});

// =============================================
// 6. ENCERRAMENTO CONTROLADO (MANTIDO)
// =============================================

const cleanup = () => {
  try {
    if (fs.existsSync(LOCK_FILE)) {
      fs.unlinkSync(LOCK_FILE);
    }
    console.log('🔴 Bot encerrado corretamente');
  } catch (err) {
    console.error('Erro durante limpeza:', err.message);
  } finally {
    process.exit();
  }
};

process.on('SIGINT', cleanup);
process.on('SIGTERM', cleanup);
process.on('uncaughtException', (err) => {
  console.error('Erro não tratado:', err);
  cleanup();
});

console.log('🤖 Bot iniciado com sucesso!');